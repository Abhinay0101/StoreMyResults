<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="header.css">
</head>
<body>
    <header class="header">
        <button class="login" onclick="location.href='login.php'">Login</button>
        <div class="name">StoreMyResults</div>
       
    </header>
    <div class="schimg"><img class="banner" src="images/results.png"></div>
</body>
</html>